% The code in this package implements the combined internal and external denoising method as described in the following paper:
% S. Anwar, F. Porikli and C. P. Huynh
% "Combined Internal and External Category-Specific Image Denoising,"
% British Machine Vision Conference (BMVC), 2017.
% Please cite the paper if you are using this code in your research.
% Please see the file License.txt for the license governing this code.

clear;
close all;

%%
addpath(genpath('BM3D'));
addpath(genpath('Blk_matching'));
addpath(genpath('Utils'));

%%
save_path = 'Results_single';
if ~exist(save_path,'dir')
    mkdir(save_path);
end


%% Paths to datasets
path = 'face\test\';
test_im = '4.png';

path_train = 'face\train\';
ext_train = '*.png';

sigma = 20;

%% read and process images.
fprintf('Sigma =%d \n', sigma);
gt   = imread(fullfile(path, test_im));

if size(gt,3)>1
    y = im2double(rgb2gray(gt));
else
    y = im2double(gt);
end

%% add noise to the test image.
randn('seed', 0 );
noisy  =   y + randn(size(y))*sigma/255; %Generate noisy image

%% Step 1
y_est = noisy;
[y_est, y_map]  = Combined_CSID( noisy, y_est,  sigma, path_train, ext_train);

%% Step 2
if (sigma> 30)
    imwrite(y_est, fullfile(save_path,['denoise_intermediate_' test_im(1:end-4) '_s' num2str(sigma) '.png']));
    imwrite(y_map, fullfile(save_path,['denoise_intermediate_map_' test_im(1:end-4) '_s' num2str(sigma) '.png']));
    
    y_est    =   y_est + 0.17*(noisy - y_est);
    [y_est, y_map]  = Combined_CSID( noisy, y_est,  sigma, path_train, ext_train);
end

PSNR_y_est= 10*log10(1/mean((y_est(:)-double(y(:))).^2));
fprintf('PSNR: %2.2f\n\n',   PSNR_y_est);

%% Write results
imwrite(y_est, fullfile(save_path,['denoise_' test_im(1:end-4) '_s' num2str(sigma) '.png']));
imwrite(y_map, fullfile(save_path,['denoise_map_' test_im(1:end-4) '_s' num2str(sigma) '.png']));
save(fullfile(save_path,'denoise_PSNR.mat'), 'PSNR_y_est');
