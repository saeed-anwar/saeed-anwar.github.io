
dataset =  load('nyu_depth_v2_labeled.mat');

blur_images = zeros(size(dataset.images), 'uint8');
for idx = 1: size(dataset.images, 4)
    idx
    im_original = dataset.images(:, :, :, idx);
    im_depth = dataset.depths(:, :, idx);
    im_db = depth_blur(im_original, im_depth);
    blur_images(:,:,:, idx) = im_db;
end
save('nyu_blur_im_v2.mat', 'blur_images', '-v7.3');