% Perform depth-based blurring of input (source) image based on its depth
% map (input), to create an output image with only image regions lying at
% depths of user's interest (input) in focus, and everything else blurred
function im_db = depth_blur(im_src, depth_map)
% INPUT ARGUMENTS:
% - im_src      : Input (source) image on which depth-blurring will be done
% - depth_map   : Depth map of the input image
% - depth_focus : Depth range(s) of the image regions to be kept in focus
% - blur_rate   : Extent to which regions of non-interest should be blurred
%
%       CAUTION : If you don't supply any value for the last input argument,
%                 I will assume it as 10, and perform blurring accordingly!
%
% OUTPUT:
% -       im_db : Output image; To view it, use imshow(im_db). Only image
%                 regions lying in user's depths of interest are in focus
%
if ~exist('im_src', 'var') || ~exist('depth_map', 'var'), disp('One of the parameter is missing!'); end
%
Ns = 11;
blur_size =  17;
for row = 1: 1: size(im_src, 1)
    parfor col = 1: 1: size(im_src, 2)
        
        sigma = double(depth_map(row, col)/2);
        
        row_min = max(row-(Ns-1)/2, 1);
        row_max = min(row+(Ns-1)/2, size(im_src,1));
        col_min = max(col-(Ns-1)/2, 1);
        col_max = min(col+(Ns-1)/2, size(im_src,2));
        
        if (row_max - row_min)< (Ns-1)/2
            row_min = size(im_src,1)-(Ns-1)/2;
            row_max = size(im_src,1);
        end
        
        if (col_max - col_min)< (Ns-1)/2
            col_min = size(im_src,2)-(Ns-1)/2;
            col_max = size(im_src,2);
        end
        
        search_window = im_src(row_min:row_max, col_min:col_max, :);
        im_db_it = imfilter(search_window, fspecial('gaussian',[blur_size, blur_size], sigma), 'replicate');
        im_db(row, col, :) = im_db_it(round(Ns/2), round(Ns/2), :);
    end
end

im_db = uint8(im_db);

% for row = 1:Nstep:height
%     for col = 1:Nstep:width
%         blk_est = y_est(row:row+N1-1, col:col+N1-1);
%         array3D = [];
%         for idx = 1:length(database)
%             search_image = database{idx};
%             row_min = max(row-(Ns-1)/2,1);
%             row_max = min(row+(Ns-1)/2,size(search_image,1));
%             col_min = max(col-(Ns-1)/2,1);
%             col_max = min(col+(Ns-1)/2,size(search_image,2));
%             if (row_max - row_min)< (Ns-1)/2
%                 row_min = size(search_image,1)-(Ns-1)/2;
%                 row_max = size(search_image,1);
%             end
%             if (col_max - col_min)< (Ns-1)/2
%                 col_min = size(search_image,2)-(Ns-1)/2;
%                 col_max = size(search_image,2);
%             end
%             search_window = search_image(row_min:row_max, col_min:col_max);
%             %             [array3D_temp, ~, ~] = blk_matching(blk_est, search_window, N2, tau_match);
%             %             array3D = cat(3, array3D, array3D_temp);
%             %
%             array3D_temp = im2colstep(search_window,[N1 N1]);
%             IDX = knnsearch(array3D_temp', blk_est(:)', 'k', N2);
%             array3D = cat(3, array3D, array3D_temp(:, IDX));
%         end